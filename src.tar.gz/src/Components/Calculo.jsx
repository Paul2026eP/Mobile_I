import React, { useState } from 'react';

const Calculo = () => {
  // 1. Criamos estados para guardar os valores dos inputs
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [resultado, setResultado] = useState('');

  const calcularIMC = () => {
    // Convertemos o texto dos inputs para números
    const p = parseFloat(peso);
    const a = parseFloat(altura.replace(',', '.')); // Aceita vírgula ou ponto

    if (p > 0 && a > 0) {
      const imc = (p / (a * a)).toFixed(2);
      setResultado(`Seu IMC é: ${imc}`);
    } else {
      setResultado('Por favor, insira valores válidos.');
    }
  };

  return (
    <div className="container">
      <h1>Calculadora do IMC</h1>
      <div className="form">
        <label>Peso (Kg)</label>
        <input 
          type="number" 
          value={peso} 
          onChange={(e) => setPeso(e.target.value)} 
          placeholder='Ex: 75' 
        />

        <label>Altura (m)</label>
        <input 
          type="number" 
          value={altura} 
          onChange={(e) => setAltura(e.target.value)} 
          placeholder='Ex: 1.75' 
        />

        {/* 2. Passamos a função sem os parênteses () */}
        <button onClick={calcularIMC}>Calcular o IMC</button>
      </div>

      <div className="resultado">
        {resultado}
      </div>
    </div>
  );
};

export default Calculo;