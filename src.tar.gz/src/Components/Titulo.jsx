import React from 'react'

const Titulo = () => {
  return (
    <div>
      <img src="https://github.com/ddgouvea/Img/blob/main/Donizete/Donizete(pb).png?raw=true" alt="" />
    </div>
  )
}

export default Titulo
