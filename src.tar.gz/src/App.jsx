import { useState } from 'react'

import './App.css'
import Titulo from './Components/Titulo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <section id="center">


        <Titulo/>

        
      </section>

      <div className="ticks"></div>
      <section id="spacer"></section>
    </>
  )
}

export default App
