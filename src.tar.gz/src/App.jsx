import { useState } from 'react'
import './App.css'
import Calculo from './Components/Calculo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <section id="center">
        <Calculo/>
        
      </section>

      <div className="ticks"></div>
      <section id="spacer"></section>
    </>
  )
}

export default App
