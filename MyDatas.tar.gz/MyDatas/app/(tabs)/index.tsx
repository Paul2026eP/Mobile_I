import React, { useState } from 'react';
import { StyleSheet } from 'react-native';

const dice_images = [
  require ('./assests/images/dado_0.png'),
  require ('./assests/images/dado_1.png'),
  require ('./assests/images/dado_2.png'),
  require ('./assests/images/dado_3.png'),
  require ('./assests/images/dado_4.png'),
  require ('./assests/images/dado_5.png'),
  require ('./assests/images/dado_6.png'),

]  

export default function HomeScreen() {
  const [diceIndex, setDiceIndex] = useState (0);
  const onDicePres = () => {
    const randomIndex = Math.floor (Math.random() *6 + 1);
    setDiceIndex(randomIndex);

  };
  const onResetPress = () =>{
    setDiceIndex(0);
  };

  return (
  <div></div>  
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 178,
    width: 290,
    bottom: 0,
    left: 0,
    position: 'absolute',
  },
});
