import type { FormData } from './types';


export function computeSimulation(data: FormData) {
  const available = data.monthlyIncome - data.essentialExpenses - data.debts;
  const monthlyNeeded = Math.ceil(data.goalCost / data.goalMonths);
  const feasibility = available >= monthlyNeeded ? 'Viável' : 'Desafiadora';
  const commitment = data.monthlyIncome > 0 ? Math.round(((data.essentialExpenses
     + data.debts) / data.monthlyIncome) * 100) : 0;

  const getSuggestions = () => {
    if (data.goalMonths <= 6) return "Poupança de alto rendimento ou Tesouro Selic";
    if (data.goalMonths <= 24) return "CDBs, LCIs e fundos de renda fixa";
    return "Diversificar com fundos de ações ou ETFs (com cautela)";
  };

  return { available, monthlyNeeded, feasibility, commitment, getSuggestions };
}
