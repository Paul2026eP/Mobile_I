import React from 'react';
import type { FormData } from './types';
import { computeSimulation } from './simulationUtils';

interface Props {
  data: FormData;
  onReset: () => void;
}

const SimulationCard: React.FC<Props> = ({ data, onReset }) => {
  const { available, monthlyNeeded, feasibility, commitment, getSuggestions } = computeSimulation(data);
  const suggestion = getSuggestions();

  return (
    <div className="simulation-card">
      <div className="card-header">
        <h2>📈 Sua Simulação Financeira Personalizada</h2>
        <button onClick={onReset} className="reset-btn">Nova Simulação</button>
      </div>

      <div className="result-section">
        <h3>Descrição</h3>
        <p><strong>Objetivo:</strong> {data.goal}</p>
        <p><strong>Valor necessário:</strong> R$ {data.goalCost.toLocaleString('pt-BR')}</p>
        <p><strong>Prazo:</strong> {data.goalMonths} meses</p>
      </div>

      <div className="result-section">
        <h3>Viabilidade da Meta</h3>
        <p className={`viability ${feasibility === 'Viável' ? 'good' : 'warning'}`}>
          {feasibility}
        </p>
        <p>Com base na sua capacidade atual de poupança.</p>
      </div>

      <div className="result-section">
        <h3>Diagnóstico Financeiro</h3>
        <p>Comprometimento atual: <strong>{commitment}%</strong> da renda</p>
        <p>Valor disponível por mês: <strong>R$ {available.toLocaleString('pt-BR')}</strong></p>
        <p>Economia mensal necessária: <strong>R$ {monthlyNeeded.toLocaleString('pt-BR')}</strong></p>
      </div>

      <div className="result-section">
        <h3>Sugestão Prática</h3>
        <p><strong>Guarde por mês:</strong> R$ {monthlyNeeded.toLocaleString('pt-BR')}</p>
        <p>Reduza gastos não essenciais e automatize a transferência para uma conta de investimento.</p>
      </div>

      <div className="result-section">
        <h3>Como Aumentar a Renda</h3>
        <ul>
          <li>Freelance ou trabalhos temporários (Uber, iFood, design, programação)</li>
          <li>Venda de produtos usados ou artesanato</li>
          <li>Cursos rápidos para qualificação profissional</li>
        </ul>
      </div>

      <div className="result-section">
        <h3>Sugestões de Investimentos</h3>
        <p><strong>Recomendado:</strong> {suggestion}</p>
        <p>Consulte um assessor ou use apps confiáveis para aplicar.</p>
      </div>

      <div className="result-section">
        <h3>Mensagem Final</h3>
        <p className="incentive">
          Você está no caminho certo! A disciplina financeira é o maior ativo que você pode construir.
          Comece pequeno, seja consistente e celebre cada conquista. O futuro financeiro que você sonha está ao seu alcance.
        </p>
        <p><strong>Dica:</strong> Revise seu plano todo mês.</p>
      </div>
    </div>
  );
};

export default SimulationCard;
