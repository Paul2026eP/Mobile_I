import React from "react";
import Calculo from "./Components/Calculo";   // ← Corrigido aqui

function App() {
  return (
    <div className="App">
      <Calculo />
    </div>
  );
}

export default App;