import React, { useState } from 'react';

const Calculo = () => {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [resultado, setResultado] = useState(null);
  const [erro, setErro] = useState('');

  const calcularIMC = () => {
    if (!peso || !altura) {
      setErro('Por favor, preencha o peso e a altura.');
      setResultado(null);
      return;
    }

    const pesoNum = parseFloat(peso.replace(',', '.'));
    const alturaNum = parseFloat(altura.replace(',', '.'));

    if (isNaN(pesoNum) || isNaN(alturaNum) || pesoNum <= 0 || alturaNum <= 0) {
      setErro('Por favor, insira valores numéricos válidos.');
      setResultado(null);
      return;
    }

    setErro('');

    const imc = (pesoNum / (alturaNum * alturaNum)).toFixed(2);

    let classificacao = '';
    let cor = '';

    if (imc < 18.5) {
      classificacao = 'Abaixo do peso';
      cor = '#e74c3c';
    } else if (imc < 25) {
      classificacao = 'Peso normal';
      cor = '#27ae60';
    } else if (imc < 30) {
      classificacao = 'Sobrepeso';
      cor = '#f39c12';
    } else if (imc < 35) {
      classificacao = 'Obesidade grau I';
      cor = '#e74c3c';
    } else if (imc < 40) {
      classificacao = 'Obesidade grau II';
      cor = '#e74c3c';
    } else {
      classificacao = 'Obesidade grau III (mórbida)';
      cor = '#c0392b';
    }

    setResultado({ imc, classificacao, cor });
  };

  return (
    <div style={styles.background}>
      <div style={styles.container}>
        <h1 style={styles.titulo}>Calculadora de IMC</h1>

        {/* Formulário */}
        <div style={styles.form}>
          <label style={styles.label}>Peso (kg):</label>
          <input
            style={styles.input}
            type="number"
            step="0.1"
            placeholder="Ex: 75 ou 75.5"
            value={peso}
            onChange={(e) => setPeso(e.target.value)}
          />

          <label style={styles.label}>Altura (m):</label>
          <input
            style={styles.input}
            type="number"
            step="0.01"
            placeholder="Ex: 1.75"
            value={altura}
            onChange={(e) => setAltura(e.target.value)}
          />

          <button style={styles.button} onClick={calcularIMC}>
            Calcular IMC
          </button>
        </div>

        {/* Resultado */}
        {erro && <p style={styles.erro}>{erro}</p>}

        {resultado && (
          <div style={styles.resultadoContainer}>
            <p style={styles.resultadoTitulo}>
              Seu IMC: <span style={styles.imcValor}>{resultado.imc}</span>
            </p>
            <p
              style={{
                ...styles.classificacao,
                backgroundColor: resultado.cor,
              }}
            >
              {resultado.classificacao}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

// Estilos
const styles = {
  background: {
    minHeight: '100vh',
    backgroundColor: '#FFA07A',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
  },
  container: {
    backgroundColor: '#E0FFFF',
    padding: '40px 30px',
    borderRadius: '16px',
    width: '100%',
    maxWidth: '420px',
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.15)',
    textAlign: 'center',
  },
  titulo: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: '30px',
  },
  form: {
    marginBottom: '20px',
  },
  label: {
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: '8px',
    display: 'block',
    textAlign: 'left',
    fontSize: '16px',
  },
  input: {
    width: '100%',
    padding: '14px',
    border: '2px solid #bdc3c7',
    borderRadius: '10px',
    fontSize: '18px',
    backgroundColor: '#fff',
    marginBottom: '20px',
    boxSizing: 'border-box',
  },
  button: {
    width: '100%',
    padding: '16px',
    backgroundColor: '#3498db',
    color: 'white',
    border: 'none',
    borderRadius: '10px',
    fontSize: '18px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
  resultadoContainer: {
    marginTop: '30px',
    paddingTop: '25px',
    borderTop: '1px solid #ddd',
  },
  resultadoTitulo: {
    fontSize: '22px',
    color: '#2c3e50',
    marginBottom: '12px',
  },
  imcValor: {
    fontWeight: 'bold',
    fontSize: '26px',
  },
  classificacao: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: 'white',
    padding: '14px 30px',
    borderRadius: '10px',
    display: 'inline-block',
    marginTop: '10px',
  },
  erro: {
    color: '#e74c3c',
    fontWeight: 'bold',
    marginTop: '20px',
    fontSize: '16px',
  },
};

export default Calculo;