function calcularIMC () {
    const peso = parseFloat (document.getElementById ('peso').value.replace (',','.'));
    const altura = parseFloat (document.getElementById ('altura').value.replace (',','.'));
    const resultadoDiv = document.getElementById ('resultado');


    if (!peso || !altura || altura <=0) {
        resultadoDiv.innerHTML = `<p class= "erro"> Por favor, insira peso e altura validos.</p>`; 
        //erro classe do CSS
        return;
    }

    const imc = (peso / (altura * altura)).toFixed(2);
    let classificacao = '';

    if (imc < 18.5) {
        classificacao = 'Abaixo do peso';
    } else if (imc < 25) {
        classificacao = 'Peso normal';  
    } else if (imc < 30) {
        classificacao = 'Sobrepeso';
    } else if (imc < 35) {
        classificacao = 'Obesidade grau I';
    } else if (imc < 40) {
        classificacao = 'Obesidade grau II';
    } else {
        classificacao = 'Obesidade grau III (morbida)';
    } 

    resultadoDiv.innerHTML = ` 
    <h2> Seu IMC: <strong>${imc} </strong></h2>
    <p class = "classificacao"> ${classificacao}</p> 
    `; //classificacao classe CSS
}
        
